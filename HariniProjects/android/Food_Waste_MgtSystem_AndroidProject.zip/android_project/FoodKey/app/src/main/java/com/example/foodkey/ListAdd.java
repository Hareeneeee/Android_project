package com.example.foodkey;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class ListAdd extends AppCompatActivity {

    private static final String TAG="ListAdd";

    DatabaseHelper myDB;
    private ListView mListView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_add);

        mListView = findViewById(R.id.lv_add_list);
        myDB = new DatabaseHelper(this);

        populateListView();
    }

    private void populateListView() {
        Log.d(TAG,"populateListView: Displaying data in listView");
        //get the data and append to the list
        Cursor data = myDB.getAllData();
        ArrayList<String> listData = new ArrayList<>();
        while(data.moveToNext()){
            listData.add(data.getString(1));
        }
        //create the list adapter and set the adapter
        ListAdapter adapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,listData);
        mListView.setAdapter(adapter);
    }


}
