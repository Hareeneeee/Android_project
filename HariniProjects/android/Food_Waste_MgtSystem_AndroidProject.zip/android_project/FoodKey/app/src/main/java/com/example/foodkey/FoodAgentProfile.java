package com.example.foodkey;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class FoodAgentProfile extends AppCompatActivity {

    Button btnHistory,btnSchedule;
    TextView tvId;

    SharedPreferences sharedPref;
    SharedPreferences.Editor editor;

    String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.food_agent_profile);

        btnHistory=findViewById(R.id.btn_history_fapro);
        btnSchedule=findViewById(R.id.btn_schedule_fapro);
        tvId=findViewById(R.id.tv_id_fapro);

        sharedPref = getSharedPreferences("sharedPrefsFoodAgent",MODE_PRIVATE);
        editor = sharedPref.edit();

//        Bundle bundle = getIntent().getExtras();
//        String data = bundle.getString("id");
            String data = sharedPref.getString("id",id);


        tvId.setText(data);

        btnHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(FoodAgentProfile.this,History.class);
                startActivity(intent);
            }
        });

        btnSchedule.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(FoodAgentProfile.this,Schedule.class);
                startActivity(intent);
            }
        });
    }
}
