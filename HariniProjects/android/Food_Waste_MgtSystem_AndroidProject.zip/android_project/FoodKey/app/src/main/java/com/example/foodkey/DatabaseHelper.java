package com.example.foodkey;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "share_food.db";
    public static final String TABLE_NAME = "food_details_table";
    public static final String COL_1 = "id";
    public static final String COL_2 = "address";
    public static final String COL_3 = "quantity";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableQuery="create table if not exists "+TABLE_NAME+" (id integer primary key autoincrement, address text not null, quantity text not null);";
        db.execSQL(createTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean insertData(String address, String quantity)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL_2,address);
        contentValues.put(COL_3,quantity);
        long result = db.insert(TABLE_NAME,null,contentValues);
        if(result == -1)
            return false;
        else
            return true;
    }

    public Cursor getAllData(){
        SQLiteDatabase db = this.getWritableDatabase();
//        String query = "SELECT * FROM"+TABLE_NAME;
//        Cursor data = db.rawQuery(query,null);
//        return data;
        Cursor res = db.rawQuery("select * from "+TABLE_NAME,null);
        return res;
    }
}
