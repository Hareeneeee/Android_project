package com.example.foodkey;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class DonateFood extends AppCompatActivity {

    Button btnVlt,btnHnspots,btnShare;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.donate_food);

        btnVlt=findViewById(R.id.btn_vlt_dtfood);
        btnHnspots=findViewById(R.id.btn_hs_dtfood);
        btnShare=findViewById(R.id.btn_share_dtfood);

        btnVlt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(DonateFood.this,Volunteer.class);
                startActivity(intent);
            }
        });

        btnHnspots.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(DonateFood.this,HungerSpots.class);
                startActivity(intent);
            }
        });
        btnShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(DonateFood.this,ShareFood.class);
                startActivity(intent);
            }
        });
    }
}
