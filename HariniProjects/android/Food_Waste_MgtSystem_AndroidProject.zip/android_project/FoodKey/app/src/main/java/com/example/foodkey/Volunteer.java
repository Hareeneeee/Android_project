package com.example.foodkey;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Volunteer extends AppCompatActivity {
    Button btnDtfood,btnHspots;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.volunteer);

        btnDtfood=findViewById(R.id.btn_df_vlt);
        btnHspots=findViewById(R.id.btn_hs_vlt);
        Bundle bundle = getIntent().getExtras();

        btnDtfood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(Volunteer.this,DonateFood.class);
                startActivity(intent);
            }
        });

        btnHspots.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(Volunteer.this,HungerSpots.class);
                startActivity(intent);
            }
        });
    }
}
