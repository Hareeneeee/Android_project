package com.example.foodkey;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class HungerSpots extends AppCompatActivity {
    Button btnDtfood,btnVlt;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hunger_spots);

        btnDtfood=findViewById(R.id.btn_df_spots);
        btnVlt=findViewById(R.id.btn_vlt_spots);



        btnDtfood.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(HungerSpots.this,DonateFood.class);
                startActivity(intent);
            }
        });
        btnVlt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(HungerSpots.this,Volunteer.class);
                startActivity(intent);
            }
        });
    }
}
