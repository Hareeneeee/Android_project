package com.example.foodkey;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ShareFood extends AppCompatActivity {

    DatabaseHelper myDB;

    Button btnSubmit;
    EditText etAddress,etQuantity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.share_food);
        myDB =new DatabaseHelper(this);

        btnSubmit=findViewById(R.id.btn_submit_share);
        etAddress=findViewById(R.id.et_add_share);
        etQuantity=findViewById(R.id.et_quantity_share);
        AddData();
    }

    public void AddData(){
        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               boolean isInserted =  myDB.insertData(etAddress.getText().toString(),etQuantity.getText().toString());
            if(isInserted = true)
                Toast.makeText(ShareFood.this,"Address added",Toast.LENGTH_SHORT).show();
            else
                Toast.makeText(ShareFood.this,"Something went wrong!",Toast.LENGTH_SHORT).show();
            }
        });
    }
}
