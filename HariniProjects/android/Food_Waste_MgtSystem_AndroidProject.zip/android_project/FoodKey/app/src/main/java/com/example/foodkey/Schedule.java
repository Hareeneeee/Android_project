package com.example.foodkey;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Schedule extends AppCompatActivity {

    Button btnFapro,btnHistory,btnShow;
    DatabaseHelper myDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.schedule);
        myDB =new DatabaseHelper(this);

        btnFapro=findViewById(R.id.btn_profile_shle);
        btnHistory=findViewById(R.id.btn_history_shle);
        btnShow=findViewById(R.id.btn_show_shle);

        Bundle bundle = getIntent().getExtras();
        viewAll();

        btnFapro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(Schedule.this,FoodAgentProfile.class);
                startActivity(intent);
            }
        });

        btnHistory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(Schedule.this,History.class);
                startActivity(intent);
            }
        });
    }


//        public void viewAll(){
//        btnShow.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Intent intent =  new Intent(Schedule.this,ListAdd.class);
//                startActivity(intent);
//            }
//        });
//        }
    public void viewAll(){
        btnShow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor res = myDB.getAllData();
                if(res.getCount() == 0){
                    showMessage("Error","No food to donate");
                    return;
                }


                StringBuffer buffer = new StringBuffer();
                while (res.moveToNext()){
                    buffer.append("ID :"+res.getString(0)+"\n");
                    buffer.append("Address :"+res.getString(1)+"\n");
                    buffer.append("Quantity"+res.getString(2)+" plates"+"\n\n");
                }

                showMessage("Data",buffer.toString());
            }
        });
    }

    public void showMessage(String title,String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}
