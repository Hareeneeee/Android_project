package com.example.foodkey;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Foodagentlogin extends AppCompatActivity {
    Button btnBack,btnSubmit;
    EditText etId,etPwd;

    SharedPreferences sharedPref;
    SharedPreferences.Editor editor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.foodagentlogin);

        btnBack=findViewById(R.id.btn_back_falogin);
        btnSubmit=findViewById(R.id.btn_submit_falogin);
        etId=findViewById(R.id.et_un_falogin);
        etPwd=findViewById(R.id.et_pwd_falogin);

        sharedPref = getSharedPreferences("sharedPrefsFoodAgent",MODE_PRIVATE);
        editor = sharedPref.edit();

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(Foodagentlogin.this,Login.class);
                startActivity(intent);
            }
        });

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id=etId.getText().toString();
                String pwd=etPwd.getText().toString();

                if(id.equals("")||pwd.equals(""))
                {
                    Toast.makeText(getBaseContext(),"Please fill all the fields",Toast.LENGTH_SHORT).show();
                }
                else
                {
                    editor.putString("id",id);
                    editor.apply();
                    Intent intent =  new Intent(Foodagentlogin.this,FoodAgentProfile.class);
//                    Bundle bundle = new Bundle();
//                    bundle.putString("id",id);
//                    intent.putExtras(bundle);
                    startActivity(intent);
                }
            }
        });

    }
}
