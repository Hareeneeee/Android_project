package com.example.foodkey;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Login extends AppCompatActivity {

    Button btnuserlogin,btnfoodagent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        btnuserlogin=findViewById(R.id.btn_user_login);
        btnfoodagent=findViewById(R.id.btn_foodag_login);

        btnfoodagent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(Login.this,Foodagentlogin.class);
                startActivity(intent);
            }
        });

        btnuserlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(Login.this,Userlogin.class);
                startActivity(intent);
            }
        });
    }
}
