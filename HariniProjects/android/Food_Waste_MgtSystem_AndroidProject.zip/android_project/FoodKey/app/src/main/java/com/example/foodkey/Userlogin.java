package com.example.foodkey;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Userlogin extends AppCompatActivity {
    Button btnBack,btnSubmit;
    EditText etUsername,etPwd;

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;

    String checkname,checkpwd;
    String name,password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.userlogin);

        btnBack=findViewById(R.id.btn_back_ulogin);
        btnSubmit=findViewById(R.id.btn_submit_ulogin);
        etUsername=findViewById(R.id.et_un_ulogin);
        etPwd=findViewById(R.id.et_pwd_ulogin);

        sharedPreferences = getSharedPreferences("sharedPrefs",MODE_PRIVATE);
        editor = sharedPreferences.edit();

        checkname=sharedPreferences.getString("name",name);
        checkpwd=sharedPreferences.getString("password",password);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =  new Intent(Userlogin.this,Login.class);
                startActivity(intent);
            }
        });

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String un=etUsername.getText().toString();
                String pwd=etPwd.getText().toString();

                if(un.equals("")||pwd.equals(""))
                {
                    Toast.makeText(getBaseContext(),"Please fill all the fields",Toast.LENGTH_SHORT).show();
                }
                else if((checkname.equals(un))&&(checkpwd.equals(pwd)))
                {
                    Intent intent =  new Intent(Userlogin.this,DonateFood.class);
                    startActivity(intent);
                }
                else
                {
                    Toast.makeText(getBaseContext(), "Wrong email ID or password", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
